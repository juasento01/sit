<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['php_info'] = "PHP Info";
$l['browser_no_iframe_support'] = "Your browser does not support iFrames.";

